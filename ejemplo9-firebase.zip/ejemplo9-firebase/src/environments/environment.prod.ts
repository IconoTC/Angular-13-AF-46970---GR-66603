
export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyCGI6e3pEA7ndRlFG74ubp_y_URE8lmxrY",
    authDomain: "angular-indra-22-nov-anabel.firebaseapp.com",
    projectId: "angular-indra-22-nov-anabel",
    storageBucket: "angular-indra-22-nov-anabel.firebasestorage.app",
    messagingSenderId: "366560174886",
    appId: "1:366560174886:web:6611352bb623a9471397e7"
  }
};
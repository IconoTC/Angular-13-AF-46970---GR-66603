import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  alumnos: any[] = [
    {valoracion: 'alta', repetidor: false, nombre: 'Juan', apellido: 'Lopez', nota: 7.5},
    {valoracion: 'media', repetidor: false, nombre: 'Maria', apellido: 'Sanchez', nota: 6.3},
    {valoracion: 'baja', repetidor: true, nombre: 'Pedro', apellido: 'Rodriguez', nota: 3.9},
    {valoracion: 'media', repetidor: true, nombre: 'Elena', apellido: 'Arias', nota: 5.4},
    {valoracion: 'baja', repetidor: false, nombre: 'Jorge', apellido: 'Martin', nota: 2.8},
    {valoracion: 'altaaaaaaa', repetidor: false, nombre: 'Susana', apellido: 'Gonzalez', nota: 9.3}
  ];
}

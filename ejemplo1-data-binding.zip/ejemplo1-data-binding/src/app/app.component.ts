import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  nombre: string = 'Anabel';
  apellido: string = "Vegas";

  deshabilitado: boolean = true;

  texto: string = "";

  constructor(){
    // Crear un temporizador que transcurra 5 segundos
    // habilite el boton
    // setTimeout(callback , 5 segundos);
    setTimeout( () => {
      this.deshabilitado = false;
    } , 5000);
  }

  saludar(): void{
    alert("Bienvenidos al curso de Angular");
  }
}
